import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'Article .dart';
import 'full_article_view.dart';

// A list of news categories.
const List<String> newsCategories = [
  'business',
  'entertainment',
  'general',
  'health',
  'science',
  'sports',
  'technology'
];

// definition  StatelessWidget to displays news categories.
class CategoriesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Scaffold  for the categories screen.
    return Scaffold(
      appBar: AppBar(
        title: Text('News Categories'),
      ),
      //  creates a scrollable list of widgets.
      body: ListView.builder(
        itemCount: newsCategories.length, // List lenth
        itemBuilder: (context, index) {
          // list tile create for each list tile.
          return ListTile(
            title: Text(newsCategories[index]), // Display the category name.
            onTap: () {
              // Navigate to CategoryDetailScreen when catogory select
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      CategoryDetailScreen(category: newsCategories[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
////////////////////////////////////////////////////////////////////////////////////////////
// The state class for CategoryDetailScreen.

class CategoryDetailScreen extends StatefulWidget {
  final String category;

  CategoryDetailScreen({required this.category});

  @override
  _CategoryDetailScreenState createState() => _CategoryDetailScreenState();
}

class _CategoryDetailScreenState extends State<CategoryDetailScreen> {
  List<Article> articles = [];

  @override
  void initState() {
    super.initState();
    fetchCategoryArticles(); //  screen initializes.
  }

// fetching article accoding to the selected catogory
  fetchCategoryArticles() async {
    var url =
        'https://newsapi.org/v2/top-headlines?country=us&category=${widget.category}&apiKey=25f8cdbf504a4d45adc549fba36a5d47';
    try {
      var response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        setState(() {
          // Update the state with articles got from the API
          articles = data['articles']
              .map<Article>((json) => Article.fromJson(json))
              .toList();
        });
      } else {
        print('Error: ${response.reasonPhrase}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    // Scaffold for the category detail screen.
    return Scaffold(
      appBar: AppBar(
        title: Text(
            'News in ${widget.category}'), // Title displaying the selected category.
      ),

      // loading indicator until articles are fetched.
      body: articles.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: articles.length, // Number of articles.
              itemBuilder: (context, index) {
                Article article = articles[index];
                //  ListTile for each article
                return ListTile(
                  leading: article.urlToImage != null
                      ? Image.network(
                          article.urlToImage!,
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) =>
                              Icon(Icons.image, size: 100),
                        )
                      : Icon(Icons.image,
                          size: 100), // Placeholder icon if no image URL

                  title: Text(article.title ?? 'No Title'),
                  subtitle: Text(article.description ??
                      'No Description'), // // Article description.
                  onTap: () {
                    //for later development
                  },
                );
              },
            ),
    );
  }
}
