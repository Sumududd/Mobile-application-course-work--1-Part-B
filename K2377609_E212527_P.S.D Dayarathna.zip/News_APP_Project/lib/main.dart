import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'Article .dart'; // article model class
import 'full_article_view.dart'; // screen to full article details
import 'search_screen.dart';
import 'categories_screen.dart';

void main() {
  // Main programme
  runApp(MyApp());
}

//////////////////////////////////// Define root widgets
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'US STORIES',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: HomeScreen(), // home screen
    );
  }
}

//////////////////////////////////////////////////// Main screen of the app
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0; // Current index of the bottom navigation bar
  List<Article> articles = []; //List definitin to store fitching article

  @override
  void initState() {
    super.initState();
    fetchArticles(); //Fitching data when screen intiate
  }

/////////////////////// Sorting article  by date
  void sortArticles(String sortBy) {
    if (sortBy == 'date_newest') {
      //  sort articles in descending order of their published date
      articles.sort((a, b) {
        // Retrieve the published date of articles a and b.
        var aDate = a.publishedAt ?? DateTime.now();
        var bDate = b.publishedAt ?? DateTime.now();
        return bDate.compareTo(aDate);
      });
    } else if (sortBy == 'date_oldest') {
      articles.sort((a, b) {
        // Retrieve the published date of articles a and b.
        // Use 'DateTime.now()' as a default value if 'publishedAt' is null.
        var aDate = a.publishedAt ?? DateTime.now();
        var bDate = b.publishedAt ?? DateTime.now();
        return aDate.compareTo(bDate);
      });
    }
    setState(() {
      // Rebuild UI with sorted articles
    });
  }

  fetchArticles() async {
    var url =
        'https://newsapi.org/v2/top-headlines?country=us&apiKey=25f8cdbf504a4d45adc549fba36a5d47'; // Fitching US top headline
    try {
      var response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        setState(() {
          articles = data['articles']
              .map<Article>((json) => Article.fromJson(json))
              .toList();
        });
      } else {
        print('Error: ${response.reasonPhrase}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

//////////////////////////////////////// build list of top stories
  Widget _buildTopStories() {
    if (articles.isEmpty) {
      return Center(child: CircularProgressIndicator());
    }
    return ListView.builder(
      itemCount: articles.length,
      itemBuilder: (context, index) {
        Article article = articles[index];
        return ListTile(
          leading: article.urlToImage != null
              ? Image.network(
                  article.urlToImage!,
                  width: 100,
                  height: 100,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      Icon(Icons.image, size: 100),
                )
              : Icon(Icons.image, size: 100),
          title: Text(article.title ?? 'No Title'),
          subtitle: Text(article.description ?? 'No Description'),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => FullArticleView(article: article),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> _screens = [
      //List of screen for bottom navigation
      _buildTopStories(), // Top stotied
      SearchScreen(), // Serch screen
      CategoriesScreen(), // Catogary screen
    ];
//// Building the Scaffold
    return Scaffold(
      appBar: AppBar(
        title: Text('US STORIES'), // app bar tittle
        actions: <Widget>[
          DropdownButton<String>(
              // Drop down menu for sorting article
              items: [
                DropdownMenuItem(value: 'date_newest', child: Text('Newest')),
                DropdownMenuItem(value: 'date_oldest', child: Text('Oldest')),
              ],
              onChanged: (value) {
                if (value != null) {
                  sortArticles(value);
                }
              },
              hint: Text(
                'Display',
                style: TextStyle(color: Colors.white, fontSize: 18.0),
              )),
        ],
      ),
      body: _screens[_currentIndex],
      // bottom Navigation bar to switch between screen
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          setState(() {
            _currentIndex = index; // update current index
          });
        },
        currentIndex: _currentIndex, // current selected index
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Top Stories',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Search',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.explore),
            label: 'Explore',
          ),
        ],
      ),
    );
  }
}
