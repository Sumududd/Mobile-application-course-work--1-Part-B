import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'Article .dart';
import 'full_article_view.dart';

// define StatefulWidget to handle dynamic content
class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<Article> searchResults = []; // List to hold the search result articles.
  String searchQuery = ""; //  variable for assighn search query.
// Function to fetch search results based on the user's query.
  void fetchSearchResults(String query) async {
    var url =
        'https://newsapi.org/v2/everything?q=$query&apiKey=25f8cdbf504a4d45adc549fba36a5d47';
    try {
      var response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        List<dynamic> articlesJson = data['articles'];
        setState(() {
          // Maping the  JSON objects to Article instances and update searchResults.
          searchResults =
              articlesJson.map((json) => Article.fromJson(json)).toList();
        });
      } else {
        print('Error: ${response.reasonPhrase}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    // Scaffold  to structure for the search screen.
    return Scaffold(
      appBar: AppBar(
        title: Text('Search News'), // Title for the app bar.
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(10.0),
            child: TextField(
              onChanged: (value) {
                setState(() {
                  searchQuery = value; // Update searchQuery as user
                });
              },
              onSubmitted: (value) {
                //
                fetchSearchResults(value);
              },
              decoration: InputDecoration(
                labelText: 'Search',
                border: OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(Icons.search),
                  onPressed: () {
                    fetchSearchResults(
                        searchQuery); // Fetch results when the search icon is pressed.
                  },
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: searchResults.length,
              itemBuilder: (context, index) {
                Article article = searchResults[index];
                return ListTile(
                  leading: article.urlToImage != null
                      ? Image.network(
                          article.urlToImage!,
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) =>
                              Icon(Icons.image, size: 100),
                        )
                      : Icon(Icons.image, size: 100),
                  title: Text(article.title ?? 'No Title'),
                  subtitle: Text(article.description ?? 'No Description'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => FullArticleView(article: article),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
