class Article {
// define as nullable when data might not be available.
  final String? title;
  final String? author;
  final String? description;
  final String? url;
  final String? urlToImage;
  final DateTime? publishedAt; // Change to DateTime
  final String? content;
  final Source? source;
// Constructor for the Article class
  Article({
    this.title,
    this.author,
    this.description,
    this.url,
    this.urlToImage,
    this.publishedAt, // Change type to DateTime
    this.content,
    this.source,
  });
// A factory constructor to create an Article instance from a map form Json
  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      title: json['title'],
      author: json['author'],
      description: json['description'],
      url: json['url'],
      urlToImage: json['urlToImage'],
      publishedAt: json['publishedAt'] != null
          ? DateTime.tryParse(json['publishedAt'])
          : null, // Parse as DateTime
      content: json['content'],
      source: json['source'] != null ? Source.fromJson(json['source']) : null,
    );
  }
}

//The Source class for  the source of a news article
class Source {
  final String? id;
  final String? name;

  Source({this.id, this.name});

  factory Source.fromJson(Map<String, dynamic> json) {
    return Source(
      id: json['id'],
      name: json['name'],
    );
  }
}
