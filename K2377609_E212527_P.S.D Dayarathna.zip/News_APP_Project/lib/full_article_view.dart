import 'package:flutter/material.dart';
import 'Article .dart';

//  StatelessWidget that displays the full details of a news article.
class FullArticleView extends StatelessWidget {
  final Article article;

// Constructor to Article object to be passed.
  FullArticleView({required this.article});

  @override
  Widget build(BuildContext context) {
    // Scaffold  structure of the screen.
    return Scaffold(
      appBar: AppBar(
        title: Text(article.title ?? 'Full Article'),
      ),
      // SingleChildScrollView  to be scrollable to view total content
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            //display the imag or  display an empty box.
            article.urlToImage != null
                ? Image.network(article.urlToImage!)
                : SizedBox(),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                article.title ?? '',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
            //padding for title text
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(article.content ?? ''), // article title
            ),
          ],
        ),
      ),
    );
  }
}
